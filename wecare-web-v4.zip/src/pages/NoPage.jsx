import React from 'react'

export default function NoPage() {
  return (
    <div><h1>404 Pages not Found</h1></div>
  )
}
